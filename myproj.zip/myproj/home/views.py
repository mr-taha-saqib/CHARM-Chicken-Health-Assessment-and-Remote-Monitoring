from django.shortcuts import render, redirect
from django.http import HttpResponseBadRequest
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.contrib import messages
from datetime import datetime
from home.models import Contact, FileUpload
from django.utils.timezone import now
from .forms import UploadForm
from .detection import process_single_image
import os
from .detection import run_detection_and_tracking
from django.shortcuts import render, redirect
from django.contrib import messages
from .detection import run_detection_and_tracking  # Your detection function
from .models import FileUpload



def index(request):
    """Renders the homepage."""
    return render(request, "index.html")

def about(request):
    """Renders the about page."""
    return render(request, "about.html")

def live(request):
    """Renders the live page."""
    return render(request, "Live.html")

def contact(request):
    """Handles contact form submissions and saves them to the database."""
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        message = request.POST.get('message')

        try:
            contact = Contact(
                name=name,
                email=email,
                phone=phone,
                message=message,
                submitted_at=now()
            )
            contact.save()
            messages.success(request, "Your message has been sent successfully!")
        except Exception as e:
            messages.error(request, f"Error saving contact form: {str(e)}")
    
    return render(request, "contact.html")

def upload_file(request):
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        
        if form.is_valid():
            uploaded_file = request.FILES['file']
            
            if uploaded_file.size > settings.MAX_UPLOAD_SIZE:
                return HttpResponseBadRequest("File too large.")
            
            fs = FileSystemStorage()
            filename = fs.save(uploaded_file.name, uploaded_file)
            file_path = fs.path(filename)
            
            output_dir = os.path.join(settings.MEDIA_ROOT, 'processed')
            os.makedirs(output_dir, exist_ok=True)
            
            try:
                processed_file_path = run_detection_and_tracking(file_path, output_dir)
                if not processed_file_path or not os.path.exists(processed_file_path):
                    raise Exception("Processed file not created.")
                
                relative_processed_path = os.path.relpath(processed_file_path, settings.MEDIA_ROOT)
                
                file_upload = FileUpload(file=filename, result=relative_processed_path)
                file_upload.save()
                
                messages.success(request, "File uploaded and processed successfully!")
                return redirect('result', file_id=file_upload.id)
            
            except Exception as e:
                messages.error(request, f"Error during file processing: {str(e)}")
                return redirect('upload')
        else:
            messages.error(request, "Invalid form submission.")
    
    else:
        form = UploadForm()
    
    return render(request, 'upload.html', {'form': form})



'''def result(request, file_id):
    """Displays the result page with the uploaded file's details and model results."""
    try:
        file_upload = FileUpload.objects.get(id=file_id)

        # Check if the result file exists
        result_url = file_upload.result.url if file_upload.result else None

        # Determine whether the result is a video or image based on file extension
        is_video = result_url.lower().endswith(('.mp4', '.mov', '.avi', '.webm')) if result_url else False

        context = {
            'result_image': result_url if not is_video else None,
            'result_video': result_url if is_video else None,
        }

        return render(request, 'result.html', context)

    except FileUpload.DoesNotExist:
        messages.error(request, "File not found.")
        return redirect('upload')
'''

def result(request, file_id):
    """Display uploaded file and processed result."""
    try:
        file_upload = FileUpload.objects.get(id=file_id)

        # Get file paths
        original_filename = os.path.basename(file_upload.file.name)
        result_filename = os.path.basename(file_upload.result) if file_upload.result else None

        context = {
            'fileupload': file_upload,
            'original_url': os.path.join(settings.MEDIA_URL, "uploads", original_filename),
            'result_url': os.path.join(settings.MEDIA_URL, "results", result_filename) if result_filename else None,
        }

        return render(request, 'result.html', context)

    except FileUpload.DoesNotExist:
        messages.error(request, "File not found.")
        return redirect('upload')