from django.contrib import admin
from home.models import Contact
# Register your models here.
admin.site.register(Contact)
#1:58 codewithharry